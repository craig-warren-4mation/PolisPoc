export interface QAPair {
  id: string;
  question: string;
  answer: string;
  category?: string;
  confidence?: number;
  refNumber?: string;
  isComplete?: boolean;
  isReviewed?: boolean;
  versionHistory?: { timestamp: number; answer: string }[];
} 