import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import Header from '@/components/Header';
import { toast } from 'sonner';
import { processTemplate } from '@/utils/documentProcessor';

interface ProcessedFieldResult {
  processedFields: Array<{
    refNumber: string;
    status: 'replaced' | 'missing';
    content?: string;
  }>;
  replacedFields: number;
  missingFields: number;
}

interface FinalizationProps {
  qaData?: Array<{
    id: string;
    question: string;
    answer: string;
    refNumber?: string;
    isReviewed?: boolean;
  }>;
}

const Finalization = ({ qaData: propQaData = [] }: FinalizationProps) => {
  const location = useLocation();
  const state = location.state as { qaData?: typeof propQaData } | null;
  const qaData = state?.qaData || propQaData;
  
  const [templateFile, setTemplateFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedFields, setProcessedFields] = useState<ProcessedFieldResult['processedFields']>([]);
  const [processingProgress, setProcessingProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Calculate some stats for display
  const replacedCount = processedFields.filter(f => f.status === 'replaced').length;
  const missingCount = processedFields.filter(f => f.status === 'missing').length;
  const reviewedAnswers = qaData.filter(qa => qa.isReviewed).length;

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      
      // Validate file type
      if (!file.name.endsWith('.docx')) {
        toast.error("Invalid file format", {
          description: "Please upload a .docx template file."
        });
        return;
      }
      
      setTemplateFile(file);
      
      // Automatically start processing when file is selected
      await processFile(file);
    }
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    setProcessingProgress(10);
    
    try {
      toast.info("Processing template", {
        description: `Scanning for placeholders in ${file.name}...`
      });
      
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProcessingProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 300);
      
      // Process the template file
      const result = await processTemplate(file, qaData);
      clearInterval(progressInterval);
      setProcessingProgress(100);
      
      if (result instanceof Blob) {
        toast.error("Unexpected result type", {
          description: "Template processing returned a Blob when it should have returned field data."
        });
        return;
      }
      
      // Update processed fields
      setProcessedFields(result.processedFields);
      
      if (result.missingFields > 0) {
        toast.warning(`${result.missingFields} missing fields detected`, {
          description: "Some placeholders couldn't be matched with reviewed answers."
        });
      } else {
        toast.success("Template processing complete", {
          description: `Successfully replaced ${result.replacedFields} placeholders.`
        });
      }
    } catch (error) {
      console.error('Error processing template:', error);
      toast.error("Template processing failed", {
        description: error instanceof Error ? error.message : "Failed to process the template file."
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = async () => {
    if (!templateFile) return;
    
    // If there are missing fields, show a warning first
    if (missingCount > 0) {
      const shouldProceed = window.confirm(
        `There are ${missingCount} placeholders that couldn't be matched with answers. ` +
        `These will remain as placeholders in the final document. Do you want to proceed?`
      );
      
      if (!shouldProceed) return;
    }
    
    try {
      setIsProcessing(true);
      
      toast.info("Preparing document", {
        description: "Generating final document with all replacements..."
      });
      
      // Generate and download the final document
      const finalDocumentBlob = await processTemplate(templateFile, qaData, true);
      
      // Create download link
      const url = URL.createObjectURL(finalDocumentBlob as Blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `finalized_${templateFile.name}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      if (missingCount > 0) {
        toast.success("Document ready", {
          description: `Document downloaded with ${missingCount} unmatched placeholders remaining.`
        });
      } else {
        toast.success("Document ready", {
          description: "Your finalized document has been downloaded."
        });
      }
    } catch (error) {
      console.error('Error generating final document:', error);
      toast.error("Download failed", {
        description: "Could not generate the final document. Please try again."
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBackToReview = () => {
    navigate('/');
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleSendEmail = () => {
    toast.info("Email feature coming soon", {
      description: "Direct email sending will be available in a future update."
    });
  };

  return (
    <div className="min-h-screen">
      <Header 
        documentTitle={templateFile?.name || "Document Finalization"} 
        pairsCount={qaData.length}
        reviewedCount={reviewedAnswers}
        showExport={false}
      />
      
      <main className="container mx-auto px-4 pt-24 pb-12 animate-fade-in">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-semibold mb-2">Document Finalization</h2>
          
          <p className="text-muted-foreground mb-8">
            Upload your business case template to automatically insert the finalized answers.
            The system will look for placeholders like {'{Ref: 1.1}'} and replace them with your reviewed answers.
          </p>
          
          {!templateFile ? (
            <div 
              className="upload-zone cursor-pointer border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-primary/70 transition-colors"
              onClick={triggerFileInput}
            >
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept=".docx"
                onChange={handleFileSelect}
              />
              
              <div className="flex flex-col items-center justify-center">
                <div className="w-16 h-16 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-8 w-8 text-primary" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={1.5} 
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" 
                    />
                  </svg>
                </div>
                
                <h3 className="text-lg font-medium mb-2">
                  Upload Business Case Template
                </h3>
                
                <p className="text-sm text-muted-foreground mb-4">
                  Click to select your DOCX template file with placeholders
                </p>
                
                <Button variant="outline">
                  Select Template File
                </Button>
              </div>
            </div>
          ) : (
            <div className="processing-panel">
              {isProcessing ? (
                <div className="processing-status p-8 border rounded-lg mb-6">
                  <h3 className="text-lg font-medium mb-3">Processing Template...</h3>
                  <Progress value={processingProgress} className="h-2 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Scanning for placeholders and inserting answers...
                  </p>
                </div>
              ) : (
                <div className="replacement-results mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium">Placeholder Replacement Summary</h3>
                    <div className="text-sm text-muted-foreground">
                      {replacedCount} replaced · {missingCount} missing
                    </div>
                  </div>
                  
                  <div className="fields-list border rounded-lg divide-y max-h-80 overflow-y-auto">
                    {processedFields.map((field, index) => (
                      <div 
                        key={index} 
                        className={`p-4 flex items-start gap-3 ${field.status === 'missing' ? 'bg-amber-50/50' : 'bg-emerald-50/50'}`}
                      >
                        <div className={`mt-0.5 flex-shrink-0 rounded-full p-1 ${field.status === 'missing' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'}`}>
                          {field.status === 'missing' ? (
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <line x1="12" y1="8" x2="12" y2="12" />
                              <line x1="12" y1="16" x2="12.01" y2="16" />
                            </svg>
                          ) : (
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M20 6L9 17l-5-5" />
                            </svg>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">
                            {field.refNumber}
                            {field.status === 'missing' && (
                              <span className="text-amber-600 ml-2 font-normal text-sm">Missing</span>
                            )}
                          </p>
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                            {field.status === 'replaced' 
                              ? field.content || '[Content replaced]' 
                              : 'No matching reviewed answer found'}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="actions-panel flex gap-3 justify-between">
                <Button variant="outline" onClick={handleBackToReview}>
                  Back to Review
                </Button>
                
                <div className="flex gap-3">
                  <Button variant="outline" onClick={handleSendEmail} disabled={isProcessing}>
                    Send via Email
                  </Button>
                  <Button 
                    onClick={handleDownload} 
                    disabled={isProcessing}
                    variant={missingCount > 0 ? "outline" : "default"}
                  >
                    Download Finalized Document
                    {missingCount > 0 && ` (${missingCount} missing)`}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Finalization;
