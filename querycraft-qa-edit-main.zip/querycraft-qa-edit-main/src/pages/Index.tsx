import { useState, useRef } from 'react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import UploadPanel from '@/components/UploadPanel';
import QADisplay from '@/components/QADisplay';
import { extractQAPairs, categorizeQA, detectIncompleteAnswers } from '@/utils/qaExtractor';
import { batchEnhanceQAPairs } from '@/utils/aiService';

interface QAPair {
  id: string;
  question: string;
  answer: string;
  category?: string;
  confidence?: number;
  refNumber?: string;
  isComplete?: boolean;
  isReviewed?: boolean;
  versionHistory?: { timestamp: number, answer: string }[];
}

const Index = () => {
  const [documentContent, setDocumentContent] = useState<string>('');
  const [documentName, setDocumentName] = useState<string>('');
  const [qaPairs, setQaPairs] = useState<QAPair[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [incompleteCount, setIncompleteCount] = useState(0);
  const [reviewedCount, setReviewedCount] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const qaPairsRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const handleContentLoaded = (content: string, fileName: string) => {
    setDocumentContent(content);
    setDocumentName(fileName);
    
    const pairs = extractQAPairs(content);
    const categorizedPairs = pairs.map(categorizeQA);
    const processedPairs = detectIncompleteAnswers(categorizedPairs);
    const incomplete = processedPairs.filter(p => !p.isComplete).length;
    
    const pairsWithHistory = processedPairs.map(pair => ({
      ...pair,
      isReviewed: false,
      versionHistory: [{ timestamp: Date.now(), answer: pair.answer }]
    }));
    
    setQaPairs(pairsWithHistory);
    setIncompleteCount(incomplete);
    setReviewedCount(0);
    
    if (incomplete > 0) {
      toast.info(`${incomplete} incomplete answers detected`, {
        description: "These answers may require your attention."
      });
    }
    
    if (pairs.length === 0) {
      toast.error("No Q&A pairs detected", {
        description: "Try a different document or ensure your document follows the expected format."
      });
    } else {
      toast.success(`${pairs.length} Q&A pairs extracted`, {
        description: `Document "${fileName}" processed successfully.`
      });
    }
  };

  const handleUpdatePair = (updatedPair: QAPair) => {
    setQaPairs(prevPairs => {
      const newPairs = prevPairs.map(pair => 
        pair.id === updatedPair.id ? updatedPair : pair
      );
      
      const newIncompleteCount = newPairs.filter(p => !p.isComplete).length;
      if (newIncompleteCount !== incompleteCount) {
        setIncompleteCount(newIncompleteCount);
      }
      
      const newReviewedCount = newPairs.filter(p => p.isReviewed).length;
      if (newReviewedCount !== reviewedCount) {
        setReviewedCount(newReviewedCount);
      }
      
      return newPairs;
    });
    
    toast.success("Q&A pair updated", {
      description: "Changes have been saved successfully."
    });
  };

  const handleDeletePair = (id: string) => {
    setQaPairs(prevPairs => {
      const pairToDelete = prevPairs.find(p => p.id === id);
      const newPairs = prevPairs.filter(pair => pair.id !== id);
      
      if (pairToDelete && !pairToDelete.isComplete) {
        setIncompleteCount(prev => prev - 1);
      }
      
      if (pairToDelete && pairToDelete.isReviewed) {
        setReviewedCount(prev => prev - 1);
      }
      
      return newPairs;
    });
    
    toast.success("Q&A pair deleted", {
      description: "The Q&A pair has been removed."
    });
  };

  const handleExport = () => {
    const exportText = qaPairs.map(pair => (
      `Q: ${pair.question}\nA: ${pair.answer}\nCategory: ${pair.category || 'Uncategorized'}\nStatus: ${pair.isReviewed ? 'Reviewed' : 'Pending Review'}\n\n`
    )).join('');
    
    const blob = new Blob([exportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${documentName.replace(/\.[^/.]+$/, '')}_qa_edited.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success("Export complete", {
      description: "The edited Q&A document has been exported."
    });
  };

  const handleBatchEnhance = async () => {
    setIsProcessing(true);
    try {
      const enhancedPairs = await batchEnhanceQAPairs(qaPairs);
      
      const enhancedWithHistory = enhancedPairs.map(pair => {
        const originalPair = qaPairs.find(p => p.id === pair.id);
        return {
          ...pair,
          versionHistory: [
            ...(originalPair?.versionHistory || []),
            { timestamp: Date.now(), answer: pair.answer }
          ]
        };
      });
      
      setQaPairs(enhancedWithHistory);
      
      const incomplete = enhancedPairs.filter(p => !p.isComplete).length;
      setIncompleteCount(incomplete);
      
      toast.success("Batch enhancement complete", {
        description: `${enhancedPairs.length} Q&A pairs have been enhanced.`
      });
    } catch (error) {
      console.error('Error enhancing pairs:', error);
      toast.error("Enhancement failed", {
        description: "Could not enhance all Q&A pairs."
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleNavigatePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      scrollToCurrentPair(currentIndex - 1);
    }
  };
  
  const handleNavigateNext = () => {
    if (currentIndex < qaPairs.length - 1) {
      setCurrentIndex(prev => prev + 1);
      scrollToCurrentPair(currentIndex + 1);
    }
  };
  
  const scrollToCurrentPair = (index: number) => {
    if (qaPairsRef.current) {
      const pairElements = qaPairsRef.current.querySelectorAll('.qa-pair-card');
      if (pairElements && pairElements[index]) {
        pairElements[index].scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  const handleGoToFinalization = () => {
    if (qaPairs.length === 0) {
      toast.warning("No document to finalize", {
        description: "Please upload and review a document first."
      });
      return;
    }
    
    const unreviewed = qaPairs.filter(qa => !qa.isReviewed).length;
    if (unreviewed > 0) {
      toast.warning(`${unreviewed} questions still need review`, {
        description: "Consider reviewing all answers before proceeding to finalization."
      });
    }
    
    navigate('/finalize', { state: { qaData: qaPairs } });
  };

  return (
    <div className="min-h-screen">
      <Header 
        documentTitle={documentName} 
        pairsCount={qaPairs.length} 
        onExport={handleExport}
        incompleteCount={incompleteCount}
        reviewedCount={reviewedCount}
        onNavigatePrev={handleNavigatePrev}
        onNavigateNext={handleNavigateNext}
      />
      
      <main className="container mx-auto px-4" ref={qaPairsRef}>
        {!documentContent ? (
          <UploadPanel onContentLoaded={handleContentLoaded} />
        ) : (
          <div className="pt-24 animate-fade-in">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-semibold">
                  Document Review
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {reviewedCount} of {qaPairs.length} questions reviewed
                  {incompleteCount > 0 && ` • ${incompleteCount} incomplete answers need attention`}
                </p>
              </div>
              
              <div className="flex gap-3">
                {qaPairs.length > 0 && (
                  <Button 
                    onClick={handleBatchEnhance}
                    disabled={isProcessing}
                    variant="outline"
                    className="focus-ring"
                  >
                    {isProcessing ? 'Processing...' : 'Enhance All with AI'}
                  </Button>
                )}
                
                <Button 
                  onClick={handleGoToFinalization} 
                  disabled={qaPairs.length === 0}
                  className="focus-ring"
                >
                  Proceed to Document Finalization
                </Button>
              </div>
            </div>
            
            <QADisplay 
              pairs={qaPairs} 
              onUpdatePair={handleUpdatePair} 
              onDeletePair={handleDeletePair} 
            />
          </div>
        )}
      </main>
    </div>
  );
};

export default Index;
