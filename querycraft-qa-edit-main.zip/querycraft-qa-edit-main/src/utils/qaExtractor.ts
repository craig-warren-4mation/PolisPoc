import mammoth from 'mammoth';
import { getFieldConfig, getFieldConfigByHeader, matchesFieldPattern } from '@/config/documentFields';

interface QAPair {
  id: string;
  question: string;
  answer: string;
  category?: string;
  confidence?: number;
  refNumber?: string;
  isComplete?: boolean;
}

// Function to extract Q&A pairs from text content
export const extractQAPairs = (content: string): QAPair[] => {
  // Split content into lines for processing
  const lines = content.split('\n');
  const pairs: QAPair[] = [];
  
  // Process potential table format first
  const tablePairs = extractTableFormat(content);
  if (tablePairs.length > 0) {
    return tablePairs.map(pair => ({
      ...pair,
      id: crypto.randomUUID(),
      confidence: calculateConfidence(pair),
      isComplete: Boolean(pair.answer && pair.answer.trim()),
    }));
  }
  
  // Process section-based format if no table is found
  let currentQuestion = '';
  let currentAnswer = '';
  let currentRefNumber = '';
  let currentCategory = '';
  let collectingAnswer = false;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Skip empty lines
    if (!line) continue;
    
    // Check for reference numbers at the beginning
    if (matchesFieldPattern(line, 'refNumber')) {
      const match = line.match(/^(\d+(\.\d+)*)\s+(.+)/);
      if (match) {
        // Save previous pair if exists
        if (currentQuestion) {
          pairs.push({
            id: crypto.randomUUID(),
            question: currentQuestion,
            answer: currentAnswer || '',
            category: currentCategory || undefined,
            refNumber: currentRefNumber || undefined,
            confidence: calculateConfidence({ question: currentQuestion, answer: currentAnswer }),
            isComplete: Boolean(currentAnswer && currentAnswer.trim()),
          });
        }
        
        currentRefNumber = match[1];
        currentQuestion = match[3];
        currentAnswer = '';
        collectingAnswer = true;
        continue;
      }
    }
    
    // Check for question patterns
    if (matchesFieldPattern(line, 'question')) {
      // Save previous pair if exists
      if (currentQuestion) {
        pairs.push({
          id: crypto.randomUUID(),
          question: currentQuestion,
          answer: currentAnswer || '',
          category: currentCategory || undefined,
          refNumber: currentRefNumber || undefined,
          confidence: calculateConfidence({ question: currentQuestion, answer: currentAnswer }),
          isComplete: Boolean(currentAnswer && currentAnswer.trim()),
        });
      }
      
      // Extract new question
      currentQuestion = line
        .replace(/^(Q:|Question:|\s*[•\-*]\s*Question:)\s*/i, '')
        .trim();
      currentAnswer = '';
      collectingAnswer = true;
      continue;
    }
    
    // Check for answer patterns
    if (matchesFieldPattern(line, 'answer')) {
      currentAnswer = line
        .replace(/^(A:|Answer:|\s*[•\-*]\s*Answer:)\s*/i, '')
        .trim();
      continue;
    }
    
    // Check for category patterns
    if (matchesFieldPattern(line, 'category')) {
      currentCategory = line
        .replace(/^(Category:|Type:)\s*/i, '')
        .trim();
      continue;
    }
    
    // Continue collecting the answer if we're in answer mode
    if (collectingAnswer) {
      // If we encounter what looks like a new section heading, stop collecting
      if (line.match(/^#+\s/) || line.match(/^[A-Z][\w\s]+:$/)) {
        collectingAnswer = false;
      } else {
        // Append to the current answer with proper spacing
        currentAnswer = currentAnswer 
          ? `${currentAnswer} ${line}` 
          : line;
      }
    }
  }
  
  // Add the last pair if exists
  if (currentQuestion) {
    pairs.push({
      id: crypto.randomUUID(),
      question: currentQuestion,
      answer: currentAnswer || '',
      category: currentCategory || undefined,
      refNumber: currentRefNumber || undefined,
      confidence: calculateConfidence({ question: currentQuestion, answer: currentAnswer }),
      isComplete: Boolean(currentAnswer && currentAnswer.trim()),
    });
  }
  
  return pairs;
};

// Helper function to extract table-formatted Q&A pairs
const extractTableFormat = (content: string): Array<{question: string; answer: string; refNumber?: string; category?: string}> => {
  const tableRows: string[] = [];
  
  // Check if content contains table markers (|)
  if (content.includes('|')) {
    const lines = content.split('\n');
    let inTable = false;
    
    for (let line of lines) {
      const trimmed = line.trim();
      
      // Skip separator rows like |---|---|---|
      if (trimmed.match(/^\|[\s\-|]+\|$/)) continue;
      
      // If line has pipe separators in the right format, it's likely a table row
      if (trimmed.match(/^\|.+\|.+\|/)) {
        tableRows.push(trimmed);
        inTable = true;
      } else if (inTable && !trimmed) {
        // Empty line after table might indicate end of table
        inTable = false;
      }
    }
  }
  
  if (tableRows.length >= 2) { // At least header + one data row
    // Process table rows
    const pairs: Array<{question: string; answer: string; refNumber?: string; category?: string}> = [];
    
    // Parse header row to identify columns
    const headerRow = tableRows[0].split('|')
      .map(cell => cell.trim())
      .filter(cell => cell); // Remove empty cells
    
    const columnMap = new Map<string, number>();
    
    // Map header cells to field names
    headerRow.forEach((header, index) => {
      const fieldConfig = getFieldConfigByHeader(header);
      if (fieldConfig) {
        columnMap.set(fieldConfig.fieldName, index);
      }
    });
    
    // Process data rows (skip header)
    for (let i = 1; i < tableRows.length; i++) {
      const cells = tableRows[i].split('|')
        .map(cell => cell.trim())
        .filter(cell => cell); // Remove empty cells
      
      if (cells.length >= 2) { // Need at least question and answer
        const pair: {question: string; answer: string; refNumber?: string; category?: string} = {
          question: cells[columnMap.get('question') || 0] || '',
          answer: cells[columnMap.get('answer') || 1] || ''
        };
        
        if (columnMap.has('refNumber')) {
          pair.refNumber = cells[columnMap.get('refNumber')!];
        }
        
        if (columnMap.has('category')) {
          pair.category = cells[columnMap.get('category')!];
        }
        
        pairs.push(pair);
      }
    }
    
    return pairs;
  }
  
  // Check for tab-separated values
  if (content.includes('\t')) {
    return extractTabSeparatedFormat(content);
  }
  
  return [];
};

// Helper function to extract tab-separated Q&A pairs
const extractTabSeparatedFormat = (content: string): Array<{question: string; answer: string; refNumber?: string; category?: string}> => {
  const lines = content.split('\n');
  const pairs: Array<{question: string; answer: string; refNumber?: string; category?: string}> = [];
  
  // Parse header row to identify columns
  const headerRow = lines[0].split('\t').map(cell => cell.trim());
  const columnMap = new Map<string, number>();
  
  // Map header cells to field names
  headerRow.forEach((header, index) => {
    const fieldConfig = getFieldConfigByHeader(header);
    if (fieldConfig) {
      columnMap.set(fieldConfig.fieldName, index);
    }
  });
  
  // Process data rows (skip header)
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;
    
    const cells = lines[i].split('\t').map(cell => cell.trim());
    
    if (cells.length >= 2) { // Need at least question and answer
      const pair: {question: string; answer: string; refNumber?: string; category?: string} = {
        question: cells[columnMap.get('question') || 0] || '',
        answer: cells[columnMap.get('answer') || 1] || ''
      };
      
      if (columnMap.has('refNumber')) {
        pair.refNumber = cells[columnMap.get('refNumber')!];
      }
      
      if (columnMap.has('category')) {
        pair.category = cells[columnMap.get('category')!];
      }
      
      pairs.push(pair);
    }
  }
  
  return pairs;
};

// Helper function to calculate confidence score
const calculateConfidence = (pair: { question: string; answer: string }): number => {
  let score = 0;
  
  // Question has content
  if (pair.question.trim()) score += 0.3;
  
  // Answer has content
  if (pair.answer.trim()) score += 0.3;
  
  // Question ends with question mark
  if (pair.question.trim().endsWith('?')) score += 0.2;
  
  // Answer is more than just a few words
  if (pair.answer.split(/\s+/).length > 5) score += 0.2;
  
  return Math.min(1, score);
};

// Categories for organizing Q&A pairs
export const categories = [
  'General',
  'Technical',
  'Product',
  'Support',
  'Policy',
  'Financial',
  'Compliance',
  'Other'
];

// Function to assign a category based on content
export const categorizeQA = (pair: QAPair): QAPair => {
  // This is a simplified implementation
  // In a real application, this would use NLP techniques
  
  const question = pair.question.toLowerCase();
  let category = 'Other';
  
  // Simple keyword matching for categorization
  if (question.match(/cost|budget|price|fund|expense|financial|money|payment/)) {
    category = 'Financial';
  } else if (question.match(/technical|technology|system|software|hardware|infrastructure|platform|architecture/)) {
    category = 'Technical';
  } else if (question.match(/product|feature|functionality|capability|service|offering/)) {
    category = 'Product';
  } else if (question.match(/support|help|assistance|maintenance|ticket|issue|problem/)) {
    category = 'Support';
  } else if (question.match(/policy|procedure|process|guideline|regulation|compliance|standard|rule/)) {
    category = 'Policy';
  } else if (question.match(/compliance|legal|regulatory|requirement|law|statute|regulation/)) {
    category = 'Compliance';
  } else if (question.match(/what|who|when|where|why|how/)) {
    category = 'General';
  }
  
  return {
    ...pair,
    category
  };
};

// Parse document file with enhanced Word support
export const parseDocument = async (file: File): Promise<string> => {
  try {
    // Handle DOCX files
    if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      const arrayBuffer = await file.arrayBuffer();
      const options = {
        styleMap: [
          "p[style-name='Heading 1'] => h1:fresh",
          "p[style-name='Heading 2'] => h2:fresh",
          "p[style-name='Question'] => question:fresh",
          "p[style-name='Answer'] => answer:fresh",
          "r[style-name='Reference Number'] => ref:fresh",
          "r[style-name='Category'] => category:fresh",
          "ul > li => p:fresh"
        ]
      };
      
      const result = await mammoth.convertToHtml({ arrayBuffer }, options);
      
      // Convert HTML to structured text while preserving formatting
      const parser = new DOMParser();
      const doc = parser.parseFromString(result.value, 'text/html');
      
      // Extract text while preserving structure
      const extractStructuredText = (element: Element): string => {
        if (element.tagName === 'H1') {
          return `\n# ${element.textContent}\n`;
        } else if (element.tagName === 'H2') {
          return `\n## ${element.textContent}\n`;
        } else if (element.tagName === 'QUESTION') {
          return `\nQuestion: ${element.textContent}\n`;
        } else if (element.tagName === 'ANSWER') {
          return `\nAnswer: ${element.textContent}\n`;
        } else if (element.tagName === 'REF') {
          return `\nRef: ${element.textContent}\n`;
        } else if (element.tagName === 'CATEGORY') {
          return `\nCategory: ${element.textContent}\n`;
        } else if (element.tagName === 'P') {
          const text = element.textContent?.trim() || '';
          // Check if this was originally a list item
          if (element.closest('ul, ol')) {
            return `• ${text}\n`;
          }
          return `${text}\n`;
        } else if (element.tagName === 'TABLE') {
          // Convert table to pipe-separated format
          const rows = Array.from(element.querySelectorAll('tr'));
          return rows.map(row => 
            `|${Array.from(row.children).map(cell => cell.textContent?.trim()).join('|')}|`
          ).join('\n') + '\n';
        }
        
        // Recursively process child elements
        return Array.from(element.children)
          .map(child => extractStructuredText(child))
          .join('');
      };
      
      return extractStructuredText(doc.body);
    }
    
    // Handle text files
    if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
      return await file.text();
    }
    
    throw new Error('Unsupported file type. Please upload a .txt or .docx file.');
  } catch (error) {
    console.error('Error parsing document:', error);
    throw new Error('Failed to parse document. Please try again.');
  }
};

// Detect missing or incomplete answers
export const detectIncompleteAnswers = (pairs: QAPair[]): QAPair[] => {
  return pairs.map(pair => ({
    ...pair,
    isComplete: Boolean(pair.answer && pair.answer.trim().length > 0)
  }));
};
