import { toast } from "sonner";
import { QAPair } from "../types";
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Note: In production, API calls should be made from backend
});

// Mock AI service to enhance answers
export const enhanceAnswer = async (question: string, answer: string): Promise<string> => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that improves answers to questions. Make answers more clear, accurate, and comprehensive while maintaining their core meaning."
        },
        {
          role: "user",
          content: `Please enhance this answer to the following question:\nQuestion: ${question}\nAnswer: ${answer}\n\nProvide only the enhanced answer without any additional text or formatting.`
        }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    const enhancedAnswer = completion.choices[0]?.message?.content?.trim() || answer;
    toast.success("AI enhancement applied");
    return enhancedAnswer;
  } catch (error) {
    console.error('OpenAI API error:', error);
    toast.error("Failed to enhance answer", {
      description: error instanceof Error ? error.message : "An unexpected error occurred"
    });
    return answer;
  }
};

// Mock check for answer accuracy
export const checkAnswerAccuracy = async (question: string, answer: string): Promise<number> => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that evaluates the accuracy and completeness of answers to questions. Provide a confidence score between 0 and 1."
        },
        {
          role: "user",
          content: `Please evaluate this answer and provide a confidence score between 0 and 1:\nQuestion: ${question}\nAnswer: ${answer}\n\nProvide only the numeric score without any additional text.`
        }
      ],
      temperature: 0.3,
      max_tokens: 10
    });

    const score = parseFloat(completion.choices[0]?.message?.content?.trim() || "0.6");
    return Math.min(Math.max(score, 0), 1); // Ensure score is between 0 and 1
  } catch (error) {
    console.error('OpenAI API error:', error);
    toast.error("Failed to check answer accuracy", {
      description: error instanceof Error ? error.message : "An unexpected error occurred"
    });
    return 0.6;
  }
};

// Mock function to get alternative phrasings for a question
export const getSimilarQuestions = async (question: string): Promise<string[]> => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that generates alternative phrasings for questions. Provide variations that maintain the same meaning but use different wording."
        },
        {
          role: "user",
          content: `Please provide 4 alternative ways to ask this question: "${question}"\n\nProvide each alternative on a new line without any additional text or formatting.`
        }
      ],
      temperature: 0.7,
      max_tokens: 200
    });

    const alternatives = completion.choices[0]?.message?.content?.trim().split('\n') || [];
    return alternatives.length > 0 ? alternatives : [question];
  } catch (error) {
    console.error('OpenAI API error:', error);
    toast.error("Failed to generate similar questions", {
      description: error instanceof Error ? error.message : "An unexpected error occurred"
    });
    return [];
  }
};

// Mock batch processing of Q&A pairs
export const batchEnhanceQAPairs = async (pairs: QAPair[]): Promise<QAPair[]> => {
  try {
    toast.info("Batch processing started", {
      description: `Enhancing ${pairs.length} Q&A pairs...`,
      duration: 3000,
    });

    // Process pairs in batches of 5 to avoid rate limits
    const batchSize = 5;
    const enhancedPairs: QAPair[] = [];

    for (let i = 0; i < pairs.length; i += batchSize) {
      const batch = pairs.slice(i, i + batchSize);
      const batchPromises = batch.map(async pair => {
        const enhancedAnswer = await enhanceAnswer(pair.question, pair.answer);
        const confidence = await checkAnswerAccuracy(pair.question, enhancedAnswer);
        return {
          ...pair,
          answer: enhancedAnswer,
          confidence
        };
      });

      const batchResults = await Promise.all(batchPromises);
      enhancedPairs.push(...batchResults);

      // Update progress
      toast.info("Processing batch", {
        description: `Enhanced ${Math.min(i + batchSize, pairs.length)} of ${pairs.length} Q&A pairs`,
        duration: 2000,
      });
    }

    toast.success("Batch processing complete", {
      description: `${pairs.length} Q&A pairs enhanced successfully.`,
      duration: 3000,
    });

    return enhancedPairs;
  } catch (error) {
    console.error('OpenAI API error:', error);
    toast.error("Failed to enhance Q&A pairs", {
      description: error instanceof Error ? error.message : "An unexpected error occurred"
    });
    return pairs;
  }
};
