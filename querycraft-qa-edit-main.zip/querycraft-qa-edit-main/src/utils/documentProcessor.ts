import mammoth from 'mammoth';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';

// Interface for processed fields information
interface ProcessedFieldResult {
  processedFields: Array<{
    refNumber: string;
    status: 'replaced' | 'missing';
    content?: string;
  }>;
  replacedFields: number;
  missingFields: number;
}

/**
 * Processes a DOCX template file to replace placeholders with QA data
 * 
 * @param file The template DOCX file
 * @param qaData Array of question-answer pairs with reference numbers
 * @param generateOutput Whether to generate the final document blob
 * @returns ProcessedFieldResult or Blob depending on generateOutput parameter
 */
export const processTemplate = async (
  file: File,
  qaData: Array<{
    id: string;
    question: string;
    answer: string;
    refNumber?: string;
    isReviewed?: boolean;
  }>,
  generateOutput: boolean = false
): Promise<ProcessedFieldResult | Blob> => {
  try {
    // Read the DOCX file
    const arrayBuffer = await file.arrayBuffer();
    
    // First pass: Extract raw text to find placeholders
    const rawResult = await mammoth.extractRawText({ arrayBuffer });
    const rawContent = rawResult.value;
    
    // Log QA data for debugging
    console.log('Received QA Data:', qaData.map(qa => ({
      refNumber: qa.refNumber,
      answer: qa.answer?.substring(0, 50) + '...',
      isReviewed: qa.isReviewed
    })));
    
    // Scan for placeholders like {Ref: X.Y}
    const placeholderRegex = /{Ref:\s*([0-9.]+)}/g;
    let match;
    const processedFields: Array<{
      refNumber: string;
      status: 'replaced' | 'missing';
      content?: string;
    }> = [];
    
    // Find all placeholders and build replacement map
    const replacements = new Map<string, string>();
    while ((match = placeholderRegex.exec(rawContent)) !== null) {
      const [fullMatch, refNumber] = match;
      console.log('Found placeholder:', fullMatch, 'with ref number:', refNumber);
      
      // Find matching QA item
      const qaItem = qaData.find(qa => qa.refNumber === refNumber);
      
      console.log('Found QA item:', qaItem ? {
        refNumber: qaItem.refNumber,
        answer: qaItem.answer?.substring(0, 50) + '...',
        isReviewed: qaItem.isReviewed
      } : 'none');
      
      // Only replace if we have an answer and it's been reviewed
      const canReplace = qaItem?.answer && qaItem?.isReviewed;
      
      processedFields.push({
        refNumber: refNumber,
        status: canReplace ? 'replaced' : 'missing',
        content: qaItem?.answer
      });
      
      if (canReplace) {
        // Store the exact placeholder text as the key
        replacements.set(fullMatch, qaItem.answer);
      }
    }
    
    // Calculate summary stats
    const replacedFields = processedFields.filter(f => f.status === 'replaced').length;
    const missingFields = processedFields.filter(f => f.status === 'missing').length;
    
    console.log('Summary:', {
      totalQAPairs: qaData.length,
      foundPlaceholders: processedFields.length,
      replacedFields,
      missingFields,
      processedFields,
      replacements: Object.fromEntries(replacements)
    });
    
    if (generateOutput) {
      // Load the template
      const zip = new PizZip(arrayBuffer);
      
      // Create a new instance with the zip file
      const doc = new Docxtemplater(zip, {
        paragraphLoop: true,
        linebreaks: true,
        delimiters: {
          start: '{',
          end: '}'
        }
      });
      
      try {
        // Create data object for template
        const templateData: Record<string, string> = {};
        replacements.forEach((value, key) => {
          // Remove the braces from the key
          const cleanKey = key.slice(1, -1); // Remove { and }
          console.log(`Template data: "${cleanKey}" -> "${value}"`);
          templateData[cleanKey] = value;
        });
        
        // Use the new API: resolveData followed by render
        await doc.resolveData(templateData);
        doc.render();
        
        // Get the generated document
        const output = doc.getZip().generate({
          type: 'uint8array',
          mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        });
        
        return new Blob([output], { 
          type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        });
      } catch (error) {
        console.error('Error rendering document:', error);
        if (error.properties && error.properties.errors) {
          console.error('Template errors:', error.properties.errors);
        }
        // If rendering fails, return the original document
        console.log('Returning original document due to rendering error');
        return new Blob([arrayBuffer], { 
          type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        });
      }
    }
    
    return {
      processedFields,
      replacedFields,
      missingFields
    };
  } catch (error) {
    console.error('Error processing template:', error);
    throw new Error('Failed to process the template document: ' + (error.message || 'Unknown error'));
  }
};
