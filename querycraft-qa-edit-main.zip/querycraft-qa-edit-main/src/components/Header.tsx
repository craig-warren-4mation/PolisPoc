
import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate, useLocation } from 'react-router-dom';

interface HeaderProps {
  documentTitle?: string;
  pairsCount?: number;
  incompleteCount?: number;
  reviewedCount?: number;
  onExport?: () => void;
  onNavigatePrev?: () => void;
  onNavigateNext?: () => void;
  showExport?: boolean;
}

const Header = ({ 
  documentTitle, 
  pairsCount = 0, 
  incompleteCount = 0, 
  reviewedCount = 0, 
  onExport, 
  onNavigatePrev, 
  onNavigateNext,
  showExport = true
}: HeaderProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const goToHome = () => {
    navigate('/');
  };
  
  const isFinalizationPage = location.pathname === '/finalize';
  
  return (
    <header className="fixed top-0 left-0 right-0 h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
      <div className="container h-full mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 cursor-pointer" onClick={goToHome}>
            <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center text-primary-foreground font-bold">
              QA
            </div>
            <span className="font-semibold hidden md:inline">
              {isFinalizationPage ? "Document Finalizer" : "Q&A Document Editor"}
            </span>
          </div>
          
          {documentTitle && (
            <>
              <span className="text-muted-foreground mx-2">|</span>
              <span className="text-muted-foreground truncate max-w-[200px]" title={documentTitle}>
                {documentTitle}
              </span>
            </>
          )}
        </div>
        
        <div className="flex items-center space-x-1 md:space-x-2">
          {pairsCount > 0 && (
            <div className="text-sm text-muted-foreground mr-2 hidden md:block">
              {reviewedCount}/{pairsCount} reviewed
              {!isFinalizationPage && incompleteCount > 0 && ` • ${incompleteCount} incomplete`}
            </div>
          )}
          
          {!isFinalizationPage && pairsCount > 0 && (
            <>
              {onNavigatePrev && onNavigateNext && (
                <div className="flex items-center mr-2">
                  <Button 
                    onClick={onNavigatePrev} 
                    variant="outline" 
                    size="icon" 
                    className="rounded-r-none border-r-0"
                    title="Previous question"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-left"><path d="m15 18-6-6 6-6"/></svg>
                  </Button>
                  <Button 
                    onClick={onNavigateNext} 
                    variant="outline" 
                    size="icon" 
                    className="rounded-l-none"
                    title="Next question"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right"><path d="m9 18 6-6-6-6"/></svg>
                  </Button>
                </div>
              )}
            </>
          )}
          
          {showExport && onExport && pairsCount > 0 && (
            <Button 
              onClick={onExport} 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-download"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Export
            </Button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
