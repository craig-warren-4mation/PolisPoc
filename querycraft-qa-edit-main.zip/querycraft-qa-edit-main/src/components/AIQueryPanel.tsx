import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import OpenAI from 'openai';
import { Lightbulb, Send, Wand2 } from 'lucide-react';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true // Note: In production, API calls should be made from backend
});

interface AIQueryPanelProps {
  selectedPair: {
    id: string;
    question: string;
    answer: string;
  } | null;
  onApplySuggestion: (suggestion: string) => void;
}

const SUGGESTED_PROMPTS = [
  "Can you improve this answer for clarity?",
  "Expand on this answer with more technical detail.",
  "Summarize the key points of this answer.",
  "Make this answer more concise while preserving key information."
];

export default function AIQueryPanel({ selectedPair, onApplySuggestion }: AIQueryPanelProps) {
  const [query, setQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [tone, setTone] = useState('professional');
  const [depth, setDepth] = useState('balanced');

  // Reset panel state when selected pair changes
  useEffect(() => {
    setQuery('');
    setAiResponse('');
    setIsGenerating(false);
    setTone('professional');
    setDepth('balanced');
  }, [selectedPair?.id]);

  const generateAIResponse = async () => {
    if (!selectedPair) return;
    
    setIsGenerating(true);
    
    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: `You are a helpful assistant that improves answers to questions. 
            Maintain a ${tone} tone and provide ${depth} level of detail in your responses.
            For 'summarized' depth, be concise and focus on key points.
            For 'balanced' depth, provide moderate detail while maintaining clarity.
            For 'detailed' depth, include comprehensive information and examples.`
          },
          {
            role: "user",
            content: `Question: ${selectedPair.question}\nCurrent Answer: ${selectedPair.answer}\n\nUser Query: ${query}\n\nPlease improve this answer based on the user's query. Maintain the specified tone and depth level.`
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      });

      const response = completion.choices[0]?.message?.content?.trim();
      if (response) {
        setAiResponse(response);
        toast.success("AI suggestion generated");
      }
    } catch (error) {
      console.error('OpenAI API error:', error);
      toast.error("Failed to generate AI suggestion", {
        description: error instanceof Error ? error.message : "An unexpected error occurred"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && selectedPair) {
      generateAIResponse();
    }
  };

  const handleSuggestedPrompt = (prompt: string) => {
    setQuery(prompt);
    setAiResponse('');
  };

  return (
    <Card className="w-full overflow-hidden">
      <CardHeader className="bg-secondary/50 pb-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Wand2 className="h-5 w-5" />
          AI Query Assistant
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-4 space-y-4">
        <div className="space-y-4">
          {selectedPair ? (
            <>
              <form onSubmit={handleSubmit} className="space-y-2">
                <Label htmlFor="aiQuery">Ask the AI about this question</Label>
                <div className="flex gap-2">
                  <Input
                    id="aiQuery"
                    placeholder="Type your query here..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="submit" 
                    size="sm" 
                    disabled={!query.trim() || isGenerating}
                    className="focus-ring"
                  >
                    {isGenerating ? 'Generating...' : <Send className="h-4 w-4" />}
                  </Button>
                </div>
              </form>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="tone">Tone</Label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger id="tone">
                      <SelectValue placeholder="Select tone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="formal">Formal</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="concise">Concise</SelectItem>
                      <SelectItem value="detailed">Detailed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="depth">Depth</Label>
                  <Select value={depth} onValueChange={setDepth}>
                    <SelectTrigger id="depth">
                      <SelectValue placeholder="Select depth" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="summarized">Summarized</SelectItem>
                      <SelectItem value="balanced">Balanced</SelectItem>
                      <SelectItem value="detailed">Data-Backed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-xs">Suggested Prompts</Label>
                <div className="flex flex-wrap gap-2">
                  {SUGGESTED_PROMPTS.map((prompt) => (
                    <Button
                      key={prompt}
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => handleSuggestedPrompt(prompt)}
                    >
                      <Lightbulb className="h-3 w-3 mr-1" />
                      {prompt}
                    </Button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-6 text-muted-foreground">
              <p>Select a question to interact with the AI assistant</p>
            </div>
          )}
        </div>
        
        {aiResponse && (
          <div className="space-y-3 pt-2">
            <Label htmlFor="aiResponse">AI Suggestion</Label>
            <Textarea
              id="aiResponse"
              value={aiResponse}
              readOnly
              className="min-h-[120px] bg-secondary/20"
            />
            <Button 
              onClick={() => onApplySuggestion(aiResponse)}
              size="sm"
              className="w-full"
            >
              Apply Suggestion
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
