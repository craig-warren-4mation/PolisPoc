import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Editor } from './Editor';
import { AIEnhance } from './AIEnhance';
import AIQueryPanel from './AIQueryPanel';
import { QAPair } from '@/types';
import { 
  Search, 
  Check, 
  History, 
  Filter, 
  Edit, 
  Wand2,
  AlertTriangle
} from 'lucide-react';

interface QADisplayProps {
  pairs: QAPair[];
  onUpdatePair: (updatedPair: QAPair) => void;
  onDeletePair: (id: string) => void;
}

const QADisplay = ({ pairs, onUpdatePair, onDeletePair }: QADisplayProps) => {
  const [editingPairId, setEditingPairId] = useState<string | null>(null);
  const [enhancingPairId, setEnhancingPairId] = useState<string | null>(null);
  const [selectedPairId, setSelectedPairId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filteredPairs, setFilteredPairs] = useState<QAPair[]>(pairs);

  // Update filtered pairs when pairs change or filters are applied
  useEffect(() => {
    let result = [...pairs];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        pair => 
          pair.question.toLowerCase().includes(query) || 
          pair.answer.toLowerCase().includes(query) ||
          (pair.refNumber && pair.refNumber.toLowerCase().includes(query)) ||
          (pair.category && pair.category.toLowerCase().includes(query))
      );
    }
    
    // Apply type filter
    switch (filterType) {
      case 'unanswered':
        result = result.filter(pair => !pair.isComplete);
        break;
      case 'ai-suggested':
        result = result.filter(pair => pair.answer.includes('[AI enhanced'));
        break;
      case 'reviewed':
        result = result.filter(pair => pair.isReviewed);
        break;
      default:
        // 'all' - no filtering needed
        break;
    }
    
    setFilteredPairs(result);
  }, [pairs, searchQuery, filterType]);

  const handleEdit = (id: string) => {
    setEditingPairId(id);
    setEnhancingPairId(null);
  };

  const handleEnhance = (id: string) => {
    setEnhancingPairId(id);
    setEditingPairId(null);
  };

  const handleSaveEdit = (updatedPair: QAPair) => {
    onUpdatePair({
      ...updatedPair,
      versionHistory: [
        ...(updatedPair.versionHistory || []),
        { timestamp: Date.now(), answer: updatedPair.answer }
      ]
    });
    setEditingPairId(null);
  };

  const handleCancelEdit = () => {
    setEditingPairId(null);
  };

  const handleSaveEnhance = (updatedPair: QAPair) => {
    onUpdatePair({
      ...updatedPair,
      versionHistory: [
        ...(updatedPair.versionHistory || []),
        { timestamp: Date.now(), answer: updatedPair.answer }
      ]
    });
    setEnhancingPairId(null);
  };

  const handleCancelEnhance = () => {
    setEnhancingPairId(null);
  };

  const handleApplySuggestion = (suggestion: string) => {
    if (!selectedPairId) return;
    
    const selectedPair = pairs.find(p => p.id === selectedPairId);
    if (!selectedPair) return;
    
    onUpdatePair({
      ...selectedPair,
      answer: suggestion.split('\n\n').slice(1, -1).join('\n\n') || suggestion,
      versionHistory: [
        ...(selectedPair.versionHistory || []),
        { timestamp: Date.now(), answer: selectedPair.answer }
      ]
    });
  };

  const handleToggleReviewed = (pair: QAPair) => {
    onUpdatePair({
      ...pair,
      isReviewed: !pair.isReviewed
    });
  };

  const handleSelectPair = (id: string) => {
    setSelectedPairId(id);
  };

  // Function to get confidence level color
  const getConfidenceColor = (confidence?: number) => {
    if (!confidence) return 'bg-gray-400';
    if (confidence >= 0.8) return 'bg-green-500';
    if (confidence >= 0.6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const selectedPair = selectedPairId ? pairs.find(p => p.id === selectedPairId) || null : null;

  return (
    <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-6 pb-12 animate-fade-in">
      <div className="md:col-span-2 space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search questions or answers..."
              className="pl-9 pr-4"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Questions</SelectItem>
              <SelectItem value="unanswered">Incomplete Answers</SelectItem>
              <SelectItem value="ai-suggested">AI Enhanced</SelectItem>
              <SelectItem value="reviewed">Reviewed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-6 max-h-[calc(100vh-220px)] overflow-y-auto pr-2">
          {filteredPairs.length > 0 ? (
            filteredPairs.map((pair) => (
              <Card 
                key={pair.id} 
                className={`overflow-hidden transition-all duration-300 hover:shadow-md ${selectedPairId === pair.id ? 'ring-2 ring-primary/50' : ''}`}
                onClick={() => handleSelectPair(pair.id)}
              >
                <CardHeader className="bg-secondary/50 pb-2">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      {pair.refNumber && (
                        <Badge variant="secondary" className="mb-1">
                          Ref: {pair.refNumber}
                        </Badge>
                      )}
                      <CardTitle className="text-lg font-medium">
                        {!pair.isComplete && (
                          <AlertTriangle className="inline-block h-4 w-4 text-amber-500 mr-1" />
                        )}
                        {pair.question}
                      </CardTitle>
                      {pair.category && (
                        <Badge variant="outline" className="mt-2">
                          {pair.category}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-2">
                      {pair.confidence !== undefined && (
                        <div className="flex items-center space-x-1">
                          <div 
                            className={`w-2 h-2 rounded-full ${getConfidenceColor(pair.confidence)}`}
                          ></div>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(pair.confidence * 100)}%
                          </span>
                        </div>
                      )}
                      
                      <div className="flex items-center h-6">
                        <Checkbox 
                          id={`review-${pair.id}`}
                          checked={pair.isReviewed}
                          onCheckedChange={() => handleToggleReviewed(pair)}
                          className="data-[state=checked]:bg-green-600"
                        />
                        <Label 
                          htmlFor={`review-${pair.id}`}
                          className="ml-1.5 text-xs"
                        >
                          Reviewed
                        </Label>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-4">
                  {editingPairId === pair.id ? (
                    <Editor 
                      pair={pair} 
                      onSave={handleSaveEdit} 
                      onCancel={handleCancelEdit} 
                    />
                  ) : enhancingPairId === pair.id ? (
                    <AIEnhance 
                      pair={pair} 
                      onSave={handleSaveEnhance} 
                      onCancel={handleCancelEnhance} 
                    />
                  ) : (
                    <p className="text-foreground leading-relaxed whitespace-pre-line">
                      {pair.answer}
                    </p>
                  )}
                </CardContent>
                
                {editingPairId !== pair.id && enhancingPairId !== pair.id && (
                  <CardFooter className="pt-0 flex justify-between">
                    <div>
                      {pair.versionHistory && pair.versionHistory.length > 0 && (
                        <Select>
                          <SelectTrigger className="h-8 text-xs">
                            <History className="h-3 w-3 mr-1" />
                            <SelectValue placeholder="Version History" />
                          </SelectTrigger>
                          <SelectContent>
                            {pair.versionHistory.map((version, index) => (
                              <SelectItem 
                                key={index} 
                                value={index.toString()}
                              >
                                {new Date(version.timestamp).toLocaleString()}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(pair.id);
                        }}
                        className="focus-ring"
                      >
                        <Edit className="h-3.5 w-3.5 mr-1" />
                        Edit
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEnhance(pair.id);
                        }}
                        className="focus-ring"
                      >
                        <Wand2 className="h-3.5 w-3.5 mr-1" />
                        Enhance with AI
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeletePair(pair.id);
                        }}
                        className="text-destructive hover:text-destructive/80 focus-ring"
                      >
                        Delete
                      </Button>
                    </div>
                  </CardFooter>
                )}
              </Card>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No Q&A pairs match your search criteria.</p>
            </div>
          )}
        </div>
      </div>
      
      <div>
        <AIQueryPanel 
          selectedPair={selectedPair} 
          onApplySuggestion={handleApplySuggestion} 
        />
      </div>
    </div>
  );
};

export default QADisplay;
