
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { enhanceAnswer, checkAnswerAccuracy } from '@/utils/aiService';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

interface QAPair {
  id: string;
  question: string;
  answer: string;
  category?: string;
  confidence?: number;
}

interface AIEnhanceProps {
  pair: QAPair;
  onSave: (updatedPair: QAPair) => void;
  onCancel: () => void;
}

export const AIEnhance = ({ pair, onSave, onCancel }: AIEnhanceProps) => {
  const [enhancedAnswer, setEnhancedAnswer] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(true);
  const [confidence, setConfidence] = useState<number | null>(null);
  const [isCheckingConfidence, setIsCheckingConfidence] = useState(false);
  
  useEffect(() => {
    const performEnhancement = async () => {
      try {
        const enhanced = await enhanceAnswer(pair.question, pair.answer);
        setEnhancedAnswer(enhanced);
      } catch (error) {
        console.error('Error enhancing answer:', error);
        setEnhancedAnswer(pair.answer);
      } finally {
        setIsEnhancing(false);
      }
    };
    
    performEnhancement();
  }, [pair]);
  
  const handleSave = () => {
    onSave({
      ...pair,
      answer: enhancedAnswer,
      confidence: confidence || pair.confidence,
    });
  };
  
  const checkConfidence = async () => {
    setIsCheckingConfidence(true);
    try {
      const score = await checkAnswerAccuracy(pair.question, enhancedAnswer);
      setConfidence(score);
    } catch (error) {
      console.error('Error checking confidence:', error);
    } finally {
      setIsCheckingConfidence(false);
    }
  };
  
  // Function to get confidence level color
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'bg-green-500 text-white';
    if (confidence >= 0.6) return 'bg-yellow-500 text-white';
    return 'bg-red-500 text-white';
  };
  
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="space-y-2">
        <Label className="flex items-center justify-between">
          <span>AI Enhanced Answer</span>
          {confidence !== null && (
            <Badge className={getConfidenceColor(confidence)}>
              {Math.round(confidence * 100)}% Confidence
            </Badge>
          )}
        </Label>
        
        {isEnhancing ? (
          <div className="space-y-2">
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full h-8" />
          </div>
        ) : (
          <Textarea
            value={enhancedAnswer}
            onChange={(e) => setEnhancedAnswer(e.target.value)}
            className="resize-none min-h-[220px]"
          />
        )}
      </div>
      
      <div className="flex justify-between pt-2">
        <Button 
          variant="outline" 
          onClick={checkConfidence}
          disabled={isEnhancing || isCheckingConfidence}
          className="focus-ring"
        >
          {isCheckingConfidence ? 'Checking...' : 'Check Accuracy'}
        </Button>
        
        <div className="space-x-2">
          <Button 
            variant="outline" 
            onClick={onCancel}
            disabled={isEnhancing}
            className="focus-ring"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={isEnhancing}
            className="focus-ring"
          >
            Apply Changes
          </Button>
        </div>
      </div>
    </div>
  );
};
