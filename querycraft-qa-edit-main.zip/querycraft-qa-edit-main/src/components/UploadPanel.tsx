
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { parseDocument } from '@/utils/qaExtractor';
import { toast } from 'sonner';

interface UploadPanelProps {
  onContentLoaded: (content: string, fileName: string) => void;
}

const UploadPanel = ({ onContentLoaded }: UploadPanelProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await processFile(files[0]);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      await processFile(files[0]);
    }
  };

  const processFile = async (file: File) => {
    // Only accept text files and DOCX files
    const validTypes = [
      'text/plain',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!validTypes.includes(file.type) && !file.name.endsWith('.txt')) {
      toast.error("Unsupported file type", {
        description: "Please upload a .txt or .docx file."
      });
      return;
    }
    
    try {
      setIsLoading(true);
      
      // Show processing toast
      toast.info("Processing document", {
        description: `Extracting content from ${file.name}...`
      });
      
      // Parse the document
      const content = await parseDocument(file);
      
      // Pass the content to the parent component
      onContentLoaded(content, file.name);
      
      toast.success("Document processed", {
        description: `Successfully extracted content from ${file.name}`
      });
    } catch (error) {
      console.error('Error processing file:', error);
      toast.error("Error processing file", {
        description: error instanceof Error ? error.message : "Could not extract content from the document."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const loadSampleDocument = () => {
    // Sample document with Q&A pairs in different formats
    const sampleContent = `# Business Case Questionnaire
    
1.1 What is the project name?
Domain Payment System Upgrade

1.2 Who is the client?
Royal Botanic Gardens and Domain Trust

1.3 What is the project timeline?
The project is expected to take 6 months, starting January 2023 and completing by June 2023.

2.1 What is the expected budget?
$590,000

2.2 What are the key project deliverables?
- Modern payment processing system
- Integration with existing booking platform
- Mobile-friendly payment interface
- Automated reconciliation reports

2.3 Project description
This project aims to automate and modernize the booking and payment processing systems for the Royal Botanic Gardens and Domain Trust. The current system relies on manual processes which are error-prone and time-consuming.

3.1 Who are the key stakeholders?
The key stakeholders include the Finance Director, Operations Manager, IT Department, and external vendors.

3.2 What success metrics will be used?
- 99.9% payment processing uptime
- 50% reduction in manual reconciliation efforts
- 30% increase in mobile bookings

4.1 What are the identified risks?
- Integration with legacy systems
- Data migration challenges
- Staff training requirements
- Compliance with payment security standards

4.2 How will risks be mitigated?
Detailed risk mitigation strategies will be developed during the planning phase. Initial approaches include a phased rollout, comprehensive testing, and staff training programs.

5.1 What alternatives were considered?
Several off-the-shelf payment systems were evaluated, including PaySystem Pro, BookPay, and VendorX. Custom development was selected as the most suitable approach based on specific requirements.

5.2 Why was the proposed solution selected?
The proposed solution offers the best balance between customization, integration capabilities, and cost-effectiveness. It also allows for future scalability.
`;

    // Provide the sample content to the parent component
    onContentLoaded(sampleContent, 'sample_business_case.txt');
    
    toast.success("Sample document loaded", {
      description: "You can now review and edit the sample Q&A pairs."
    });
  };

  return (
    <div className="w-full max-w-2xl mx-auto pt-24 pb-12 px-4 animate-fade-in">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
          Q&A Document Editor
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          Upload a document to extract question-answer pairs. 
          Then review, edit, and enhance answers with AI assistance.
        </p>
      </div>
      
      <div 
        className={`drop-zone ${isDragging ? 'active' : ''} ${isLoading ? 'opacity-70' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={triggerFileInput}
      >
        <input 
          type="file" 
          ref={fileInputRef}
          className="hidden" 
          accept=".txt,.docx"
          onChange={handleFileSelect}
        />
        
        <div className="flex flex-col items-center justify-center">
          <div className="w-16 h-16 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-8 w-8 text-primary" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={1.5} 
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" 
              />
            </svg>
          </div>
          
          <h3 className="text-lg font-medium mb-2">
            {isLoading ? 'Processing...' : 'Upload your document'}
          </h3>
          
          <p className="text-sm text-muted-foreground mb-4">
            Drag and drop a file here, or click to browse
          </p>
          
          <div className="text-xs text-muted-foreground">
            Supported formats: TXT, DOCX
          </div>
        </div>
      </div>
      
      <div className="mt-8 text-center">
        <p className="text-sm text-muted-foreground">
          Don't have a document? Try our <Button onClick={loadSampleDocument} variant="link" className="p-0 h-auto">sample document</Button>
        </p>
      </div>
    </div>
  );
};

export default UploadPanel;
