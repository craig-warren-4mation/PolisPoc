
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { categories } from '@/utils/qaExtractor';

interface QAPair {
  id: string;
  question: string;
  answer: string;
  category?: string;
  confidence?: number;
}

interface EditorProps {
  pair: QAPair;
  onSave: (updatedPair: QAPair) => void;
  onCancel: () => void;
}

export const Editor = ({ pair, onSave, onCancel }: EditorProps) => {
  const [editedQuestion, setEditedQuestion] = useState(pair.question);
  const [editedAnswer, setEditedAnswer] = useState(pair.answer);
  const [editedCategory, setEditedCategory] = useState(pair.category || 'General');
  
  const handleSave = () => {
    onSave({
      ...pair,
      question: editedQuestion,
      answer: editedAnswer,
      category: editedCategory,
    });
  };
  
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="space-y-2">
        <Label htmlFor="question">Question</Label>
        <Textarea
          id="question"
          value={editedQuestion}
          onChange={(e) => setEditedQuestion(e.target.value)}
          className="resize-none min-h-[80px]"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="answer">Answer</Label>
        <Textarea
          id="answer"
          value={editedAnswer}
          onChange={(e) => setEditedAnswer(e.target.value)}
          className="resize-none min-h-[160px]"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <Select 
          value={editedCategory} 
          onValueChange={setEditedCategory}
        >
          <SelectTrigger id="category" className="w-full">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex justify-end space-x-2 pt-2">
        <Button 
          variant="outline" 
          onClick={onCancel}
          className="focus-ring"
        >
          Cancel
        </Button>
        <Button 
          onClick={handleSave}
          className="focus-ring"
        >
          Save Changes
        </Button>
      </div>
    </div>
  );
};
