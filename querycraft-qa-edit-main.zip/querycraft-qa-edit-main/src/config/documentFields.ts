export interface FieldPattern {
  pattern: RegExp;
  type: 'prefix' | 'suffix' | 'exact';
}

export interface FieldConfig {
  fieldName: string;
  headerAliases: string[];
  textPatterns: FieldPattern[];
}

export const documentFields: FieldConfig[] = [
  {
    fieldName: 'question',
    headerAliases: ['question', 'prompt', 'query', 'q'],
    textPatterns: [
      { pattern: /^Q:/, type: 'prefix' },
      { pattern: /^Question:/, type: 'prefix' },
      { pattern: /^[•\-*]\s*Question:/, type: 'prefix' },
      { pattern: /^\d+(\.\d+)*\s+/, type: 'prefix' },
      { pattern: /\?$/, type: 'suffix' }
    ]
  },
  {
    fieldName: 'answer',
    headerAliases: ['answer', 'response', 'solution', 'reply', 'a'],
    textPatterns: [
      { pattern: /^A:/, type: 'prefix' },
      { pattern: /^Answer:/, type: 'prefix' },
      { pattern: /^[•\-*]\s*Answer:/, type: 'prefix' }
    ]
  },
  {
    fieldName: 'refNumber',
    headerAliases: ['ref', 'reference', 'id', 'no', 'number', 'ref no', 'ref #'],
    textPatterns: [
      { pattern: /^(\d+(\.\d+)*)\s+/, type: 'prefix' },
      { pattern: /^(\d+(\.\d+)*)(\s+|$)/, type: 'exact' }
    ]
  },
  {
    fieldName: 'category',
    headerAliases: ['category', 'type', 'group', 'section', 'topic'],
    textPatterns: [
      { pattern: /^Category:/, type: 'prefix' },
      { pattern: /^Type:/, type: 'prefix' }
    ]
  }
];

// Helper function to find field config by name
export const getFieldConfig = (fieldName: string): FieldConfig | undefined => {
  return documentFields.find(field => field.fieldName === fieldName);
};

// Helper function to find field config by header alias
export const getFieldConfigByHeader = (header: string): FieldConfig | undefined => {
  const lowerHeader = header.toLowerCase().trim();
  return documentFields.find(field => 
    field.headerAliases.some(alias => lowerHeader.includes(alias.toLowerCase()))
  );
};

// Helper function to test if a line matches a field's text patterns
export const matchesFieldPattern = (line: string, fieldName: string): boolean => {
  const config = getFieldConfig(fieldName);
  if (!config) return false;

  return config.textPatterns.some(pattern => {
    if (pattern.type === 'prefix') {
      return pattern.pattern.test(line);
    } else if (pattern.type === 'suffix') {
      return pattern.pattern.test(line);
    } else { // exact
      return pattern.pattern.test(line);
    }
  });
};

// Export the placeholder pattern for the template processor
export const placeholderPattern = /{Ref:\s*([a-zA-Z0-9.-]+)}/g;
